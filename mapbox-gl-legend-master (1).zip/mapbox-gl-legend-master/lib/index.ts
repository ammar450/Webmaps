export { default as MapboxLegendControl, LegendOptions } from './legend-control';
